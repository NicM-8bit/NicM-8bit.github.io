package com.nicm.eventtracker;

import java.util.ArrayList;

public class EventFilter {
    public static ArrayList<Event> filterByCategory(
            ArrayList<Event> events,
            int categoryId) {

        ArrayList<Event> filteredEvents = new ArrayList<>();

        if (categoryId == 0) {
            filteredEvents.addAll(events);
            return filteredEvents;
        }

        for (Event event : events) {
            if (event.getCategoryId() == categoryId) {
                filteredEvents.add(event);
            }
        }

        return filteredEvents;
    }
}
