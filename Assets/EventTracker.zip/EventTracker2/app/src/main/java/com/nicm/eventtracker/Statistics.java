package com.nicm.eventtracker;

public class Statistics {
    private int totalEvents;
    private int workEvents;
    private int schoolEvents;
    private int personalEvents;
    private int otherEvents;

    public Statistics(int totalEvents,
                      int workEvents,
                      int schoolEvents,
                      int personalEvents,
                      int otherEvents) {
        this.totalEvents = totalEvents;
        this.workEvents = workEvents;
        this.schoolEvents = schoolEvents;
        this.personalEvents = personalEvents;
        this.otherEvents = otherEvents;
    }

    public int getTotalEvents() {
        return totalEvents;
    }

    public int getWorkEvents() {
        return workEvents;
    }

    public int getSchoolEvents() {
        return schoolEvents;
    }

    public int getPersonalEvents() {
        return personalEvents;
    }

    public int getOtherEvents() {
        return otherEvents;
    }
}
