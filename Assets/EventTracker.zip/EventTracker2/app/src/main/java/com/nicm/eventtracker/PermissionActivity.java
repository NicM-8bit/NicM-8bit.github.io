package com.nicm.eventtracker;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class PermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;

    private Button buttonAllowSms, buttonDenySms;
    private TextView textStatus;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        buttonAllowSms = findViewById(R.id.buttonAllowSms);
        buttonDenySms = findViewById(R.id.buttonDenySms);
        textStatus = findViewById(R.id.textStatus);

        preferences = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        updateStatusText();

        buttonAllowSms.setOnClickListener(v -> requestSmsPermission());

        buttonDenySms.setOnClickListener(v -> {
            savePermissionPreference(false);
            textStatus.setText("Permission denied. Notifications disabled.");
            Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(this, CalendarActivity.class));
            finish();
        });
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            == PackageManager.PERMISSION_GRANTED) {
            savePermissionPreference(true);
            textStatus.setText("SMS permission already granted.");
            Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();

            startActivity(new Intent(this, CalendarActivity.class));
            finish();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                savePermissionPreference(true);
                textStatus.setText("Permission granted! SMS notifications enabled.");
                Toast.makeText(this, "Permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                savePermissionPreference(false);
                textStatus.setText("Permission denied. Notifications disabled.");
                Toast.makeText(this, "Permission denied.", Toast.LENGTH_SHORT).show();
            }

            startActivity(new Intent(this, CalendarActivity.class));
            finish();
        }
    }

    private void updateStatusText() {
        boolean smsAllowed = preferences.getBoolean("sms_permission", false);
        if (smsAllowed) {
            textStatus.setText("Permission already granted. SMS notifications active.");
        } else {
            textStatus.setText("No permission selected yet.");
        }
    }

    private void savePermissionPreference(boolean granted) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("sms_permission", granted);
        editor.apply();
    }
}
