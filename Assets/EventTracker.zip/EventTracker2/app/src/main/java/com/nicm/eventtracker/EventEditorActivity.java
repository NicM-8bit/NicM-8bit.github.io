package com.nicm.eventtracker;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class EventEditorActivity extends AppCompatActivity {

    private TextView textSelectedDate;
    private EditText editEventTitle, editEventDescription, editEventTime;
    private Button buttonSave, buttonDelete, buttonCancel;
    private Spinner spinnerCategory;
    private ArrayList<Category> categories;
    private EventManager eventManager;
    private String selectedDate;
    private int eventId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_editor);

        textSelectedDate = findViewById(R.id.textSelectedDate);
        editEventTitle = findViewById(R.id.editEventTitle);
        editEventTime = findViewById(R.id.editEventTime);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        editEventDescription = findViewById(R.id.editEventDescription);
        buttonSave = findViewById(R.id.buttonSave);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonCancel = findViewById(R.id.buttonCancel);

        eventManager = new EventManager(this);

        categories = eventManager.getAllCategories();

        ArrayAdapter<Category> categoryAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        categories
                );
        categoryAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        Intent intent = getIntent();

        eventId = intent.getIntExtra("event_id", -1);

        if (eventId != -1) {
            loadEventDetails(eventId);
        } else {
            selectedDate = intent.getStringExtra("date");
            textSelectedDate.setText("Selected Date: " + selectedDate);
        }

        // timepicker setup
        editEventTime.setFocusable(false);
        editEventTime.setOnClickListener(v -> showTimePicker());

        // save
        buttonSave.setOnClickListener(v -> saveEvent());

        // Delete
        buttonDelete.setOnClickListener(v -> deleteEvent());

        // cancel
        buttonCancel.setOnClickListener(v -> finish());
    }

    private void showTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (TimePicker view, int hourOfDay, int minuteOfHour) -> {
            String amPm = (hourOfDay >= 12) ? "PM" : "AM";
            int hourFormatted = (hourOfDay % 12 == 0) ? 12 : hourOfDay % 12;
            String formatted = String.format("%02d:%02d %s", hourFormatted, minuteOfHour, amPm);
            editEventTime.setText(formatted);
        }, hour, minute, false);

        timePickerDialog.show();
    }

    private void saveEvent() {
        String title = editEventTitle.getText().toString().trim();
        String desc = editEventDescription.getText().toString().trim();
        String time = editEventTime.getText().toString().trim();

        if (title.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please enter title and time", Toast.LENGTH_SHORT).show();
            return;
        }

        Event event;

        Category selectedCategory = (Category) spinnerCategory.getSelectedItem();

        if (eventId == -1) {
            event = new Event(title, desc, selectedDate, time, selectedCategory.getId());
        } else {
            event = new Event(eventId, title, desc, selectedDate, time, selectedCategory.getId());
        }

        boolean success = eventManager.saveEvent(event);

        if (!success) {
            Toast.makeText(this, "Error saving event", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        boolean smsAllowed = prefs.getBoolean("sms_permission_granted", false);


        if (smsAllowed &&
        ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                String dateTimeString = selectedDate + " " + time;
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                Calendar eventCal = Calendar.getInstance();
                eventCal.setTime(format.parse(dateTimeString));

                eventCal.add(Calendar.MINUTE, -10);

                Intent intent = new Intent(this, SmsReminderReceiver.class);
                intent.putExtra("event_title", title);
                intent.putExtra("event_date", selectedDate);
                intent.putExtra("event_time", time);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        this,
                        (int) System.currentTimeMillis(),
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                );

                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (alarmManager != null) {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, eventCal.getTimeInMillis(), pendingIntent);
                }

                Toast.makeText(this, "SMS reminder schedule 10 min before event", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to schedule SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            boolean hasAskedForPermission = prefs.getBoolean("hasAskedForPermission", false);
            if (!hasAskedForPermission) {
                Intent intent = new Intent(EventEditorActivity.this, PermissionActivity.class);
                startActivity(intent);
                prefs.edit().putBoolean("hasAskedForPermission", true).apply();
            } else {
                Toast.makeText(this, "SMS disabled - reminder not scheduled", Toast.LENGTH_SHORT).show();
            }
        }
        Toast.makeText(this, "Event saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void deleteEvent() {
        if (eventId != -1) {
            boolean success = eventManager.deleteEvent(eventId);
            Toast.makeText(this, success ? "Event deleted" : "Delete failed", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private void loadEventDetails(int id) {
        Event event = eventManager.getEvent(id);

        if (event != null) {
            editEventTitle.setText(event.getTitle());
            editEventDescription.setText(event.getDescription());
            editEventTime.setText(event.getTime());

            for (int i = 0; i < categories.size(); i++) {
                if (categories.get(i).getId() == event.getCategoryId()) {
                    spinnerCategory.setSelection(i);
                    
                    break;
                }
            }

            selectedDate = event.getDate();
            textSelectedDate.setText("Selected Date: " + selectedDate);
        }
    }
}
