package com.nicm.eventtracker;

public class Event {
    private int id;
    private String title;
    private String description;
    private String date;
    private String time;
    private int categoryId;

    public Event() {
    }

    public Event(String title, String description, String date, String time, int categoryId) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.categoryId = categoryId;
    }

    public Event(int id, String title, String description, String date, String time, int categoryId) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.date = date;
        this.time = time;
        this.categoryId = categoryId;
    }

    // Getters

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public int getCategoryId() {
        return categoryId;
    }

    // Setters

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
}
