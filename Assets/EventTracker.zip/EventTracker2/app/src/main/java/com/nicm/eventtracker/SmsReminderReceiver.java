package com.nicm.eventtracker;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;
public class SmsReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("event_title");
        String date = intent.getStringExtra("event_date");
        String time = intent.getStringExtra("event_time");

        // default num testing
        String phoneNumber = "5554";
        String message = "Reminder: '" + title + "' starts at " + time + " on " + date;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(context, "SMS Reminder sent for " + title, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(context, "Failed to send reminder: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
