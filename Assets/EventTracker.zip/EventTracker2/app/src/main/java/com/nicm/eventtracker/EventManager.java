package com.nicm.eventtracker;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class EventManager {
    private EventDatabaseHelper dbHelper;

    private int getMinutes(Event event) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("hh:mm a", Locale.getDefault());

            Date date = format.parse(event.getTime());

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);

            return calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE);
        } catch (Exception e) {
            return Integer.MAX_VALUE;
        }
    }

    private void sortEvents(ArrayList<Event> events) {
        events.sort((e1, e2) ->
                Integer.compare(getMinutes(e1), getMinutes(e2)));
    }

    private ArrayList<Event> searchEvents(ArrayList<Event> events, String query) {
        ArrayList<Event> results = new ArrayList<>();

        if (query == null || query.trim().isEmpty()) {
            return new ArrayList<>(events);
        }

        String search = query.toLowerCase().trim();

        for (Event event : events) {
            if (event.getTitle().toLowerCase().contains(search)) {
                results.add(event);
            }
        }

        return results;
    }

    public EventManager(Context context) {
        dbHelper = new EventDatabaseHelper(context);
    }

    public boolean saveEvent(Event event) {
        if (event.getTitle() == null || event.getTitle().trim().isEmpty()) {
            return false;
        }

        if (event.getTime() == null || event.getTime().trim().isEmpty()) {
            return false;
        }

        if(event.getId() == 0) {
            return dbHelper.addEvent(event);
        }

        return dbHelper.updateEvent(event);
    }

    public boolean addCategory(Category category) {
        if (category.getName() == null || category.getName().trim().isEmpty()) {
            return false;
        }

        return dbHelper.addCategory(category);
    }

    public ArrayList<Event> getAllEvents(){
        ArrayList<Event> events = dbHelper.getAllEvents();

        sortEvents(events);

        return events;
    }

    public ArrayList<Category> getAllCategories(){
        ArrayList<Category> categories = dbHelper.getAllCategories();

        return categories;
    }

    public ArrayList<Event> getEvents(String date){
        if (date == null || date.trim().isEmpty()) {
            return new ArrayList<>();
        }

        ArrayList<Event> events = dbHelper.getEvents(date);

        sortEvents(events);

        return events;
    }

    public Event getEvent(int id){
        if (id <= 0) {
            return null;
        }

        return dbHelper.getEvent(id);
    }

    public Category getCategory(int id) {
        if (id <= 0) {
            return null;
        }

        return dbHelper.getCategory(id);
    }

    public boolean deleteEvent(int id){
        if (id <= 0) {
            return false;
        }

        return dbHelper.deleteEvent(id);
    }

    public ArrayList<Event> searchEvents(String date, String query) {
        ArrayList<Event> events = getEvents(date);

        return searchEvents(events, query);
    }

    public Statistics getWeeklyStatistics(
            String startDate,
            String endDate) {
        return dbHelper.getWeeklyStatistics(
                startDate,
                endDate);
    }
}
