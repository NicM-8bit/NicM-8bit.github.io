package com.nicm.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class EventDatabaseHelper extends SQLiteOpenHelper{

    private static final String DATABASE_NAME = "eventtracker.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_EVENTS = "events";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESC = "description";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TIME = "time";

    private static final String TABLE_CATEGORIES = "categories";

    private static final String COLUMN_CATEGORY_ID = "category_id";
    private static final String COLUMN_CATEGORY_NAME = "category_name";

    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CATEGORIES_TABLE =
                "CREATE TABLE " + TABLE_CATEGORIES + " ("
                    + COLUMN_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + COLUMN_CATEGORY_NAME + " TEXT UNIQUE NOT NULL)";
        db.execSQL(CREATE_CATEGORIES_TABLE);

        String CREATE_EVENTS_TABLE = "CREATE TABLE " + TABLE_EVENTS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_TITLE + " TEXT, "
                + COLUMN_DESC + " TEXT, "
                + COLUMN_DATE + " TEXT, "
                + COLUMN_TIME + " TEXT, "
                + COLUMN_CATEGORY_ID + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_CATEGORY_ID + ") REFERENCES "
                + TABLE_CATEGORIES + "(" + COLUMN_CATEGORY_ID + "))";
        db.execSQL(CREATE_EVENTS_TABLE);

        insertCategory(db, "School");
        insertCategory(db, "Work");
        insertCategory(db, "Personal");
        insertCategory(db, "Medical");
        insertCategory(db, "Family");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CATEGORIES);
        onCreate(db);
    }

    private void insertCategory(SQLiteDatabase db, String name) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, name);
        db.insert(TABLE_CATEGORIES, null, values);
    }

    // Helper
    private Event cursorToEvent(Cursor cursor) {
        Event event = new Event();

        event.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
        event.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE)));
        event.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESC)));
        event.setDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE)));
        event.setTime(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TIME)));
        event.setCategoryId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_ID)));

        return event;
    }

    private Category cursorToCategory(Cursor cursor) {
        Category category = new Category();

        category.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_ID)));
        category.setName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_NAME)));

        return category;
    }

    // CRUD functionality

    // CREATE
    public boolean addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, event.getTitle());
        values.put(COLUMN_DESC, event.getDescription());
        values.put(COLUMN_DATE, event.getDate());
        values.put(COLUMN_TIME, event.getTime());
        values.put(COLUMN_CATEGORY_ID, event.getCategoryId());
        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return result != -1;
    }

    public boolean addCategory(Category category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_CATEGORY_NAME, category.getName());
        long result = db.insert(TABLE_EVENTS, null, values);
        db.close();
        return result != -1;
    }

    // READ all
    public ArrayList<Event> getAllEvents() {
        ArrayList<Event> events = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS, null);

        if (cursor.moveToFirst()) {
            do {
                events.add(cursorToEvent(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();

        return events;
    }

    public ArrayList<Category> getAllCategories() {
        ArrayList<Category> categories = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CATEGORIES, null);

        if (cursor.moveToFirst()) {
            do {
                categories.add(cursorToCategory(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();

        return categories;
    }

    // READ from date
    public ArrayList<Event> getEvents(String date) {
        ArrayList<Event> events = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " WHERE "
                + COLUMN_DATE + "=?", new String[]{date});

        if (cursor.moveToFirst()) {
            do {
                events.add(cursorToEvent(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();

        return events;
    }

    // READ from id
    public Event getEvent(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " WHERE "
                + COLUMN_ID + "=?",new String[]{String.valueOf(id)});

        Event event = null;

        if (cursor.moveToFirst()) {
            event = cursorToEvent(cursor);
        }

        cursor.close();

        return event;
    }

    public Category getCategory(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_CATEGORIES + " WHERE "
                + COLUMN_CATEGORY_ID + "=?",new String[]{String.valueOf(id)});

        Category category = null;

        if (cursor.moveToFirst()) {
            category = cursorToCategory(cursor);
        }

        cursor.close();

        return category;
    }

    // UPDATE
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, event.getTitle());
        values.put(COLUMN_DESC, event.getDescription());
        values.put(COLUMN_DATE, event.getDate());
        values.put(COLUMN_TIME, event.getTime());
        values.put(COLUMN_CATEGORY_ID, event.getCategoryId());
        int rows = db.update(TABLE_EVENTS, values, "id=?", new String[]{String.valueOf(event.getId())});
        db.close();
        return rows > 0;
    }

    // DELETE
    public boolean deleteEvent(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_EVENTS, "id=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // STATS
    public Statistics getWeeklyStatistics(String startDate,
                                          String endDate) {
        int totalEvents = 0;
        int workEvents = 0;
        int schoolEvents = 0;
        int personalEvents = 0;
        int otherEvents = 0;

        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT " + COLUMN_CATEGORY_NAME + " FROM " + TABLE_EVENTS + " INNER JOIN " +
                TABLE_CATEGORIES + " ON " + TABLE_EVENTS + "." + COLUMN_CATEGORY_ID + " = " +
                TABLE_CATEGORIES + "." + COLUMN_CATEGORY_ID + " WHERE " + COLUMN_DATE + " >= ? " +
                " AND " + COLUMN_DATE + " <= ?";

        Cursor cursor = db.rawQuery(query, new String[]{startDate, endDate});

        while (cursor.moveToNext()) {
            totalEvents++;

            String category =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_NAME)
                    );

            switch(category) {
                case "Work":
                    workEvents++;
                    break;

                case "School":
                    schoolEvents++;
                    break;

                case "Personal":
                    personalEvents++;
                    break;

                default:
                    otherEvents++;
                    break;
            }

        }

        cursor.close();

        return new Statistics(
                totalEvents,
                workEvents,
                schoolEvents,
                personalEvents,
                otherEvents);
    }
}
