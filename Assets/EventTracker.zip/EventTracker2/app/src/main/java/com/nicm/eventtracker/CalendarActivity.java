package com.nicm.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class CalendarActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private SearchView searchView;
    private Button buttonAddEvent;
    private ImageButton infoButton;
    private TextView eventsView;
    private ListView eventList;
    private Spinner categorySpinner;
    private ArrayList<Category> categories;
    private EventManager eventManager;
    private ArrayAdapter<String> adapter;
    //private ArrayList<String> eventData;
    //private ArrayList<Integer> eventIds;
    private ArrayList<Event> events;
    private ArrayList<String> displayEvents;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        calendarView = findViewById(R.id.calendarView);
        searchView = findViewById(R.id.searchEvents);
        categorySpinner = findViewById(R.id.categorySpinner);
        infoButton = findViewById(R.id.btnInfo);

        eventManager = new EventManager(this);

        categories = eventManager.getAllCategories();
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        eventsView = findViewById(R.id.eventsView);
        eventList = findViewById(R.id.eventList);

        events = new ArrayList<>();
        displayEvents = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayEvents);
        eventList.setAdapter(adapter);

        ArrayList<String> categoryNames = new ArrayList<>();
        categoryNames.add("All");

        for (Category category : categories) {
            categoryNames.add(category.getName());
        }

        ArrayAdapter<String> spinnerAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        categoryNames);
        spinnerAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(spinnerAdapter);

        // Default day - today
        selectedDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                .format(new java.util.Date(calendarView.getDate()));
        loadEvents(selectedDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            month += 1;
            selectedDate = String.format("%04d-%02d-%02d", year, month, dayOfMonth);
            eventsView.setText("Events for " + selectedDate + ":");
            loadEvents(selectedDate);
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                loadEvents(selectedDate, newText);

                return true;
            }
        });

        categorySpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> parent,
                                               android.view.View view,
                                               int position,
                                               long id) {

                        loadEvents(
                                selectedDate,
                                searchView.getQuery().toString());
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(CalendarActivity.this, EventEditorActivity.class);
            intent.putExtra("date", selectedDate);
            startActivity(intent);
        });

        infoButton.setOnClickListener(v -> showStatistics());

        eventList.setOnItemClickListener((parent, view, position, id) -> {

            if (events.size() <= position) {
                return;
            }

            Event event = events.get(position);

            Intent intent = new Intent(CalendarActivity.this, EventEditorActivity.class);

            intent.putExtra("event_id", event.getId());

            startActivity(intent);
        });
    }



    @Override
    protected void onResume() {
        super.onResume();
        loadEvents(selectedDate);
    }

    private void showStatistics() {
        Calendar calendar = Calendar.getInstance();

        SimpleDateFormat format =
                new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        Calendar start = (Calendar) calendar.clone();
        start.set(Calendar.DAY_OF_WEEK, start.getFirstDayOfWeek());

        String startDate = format.format(start.getTime());

        Calendar end = (Calendar) start.clone();
        end.add(Calendar.DAY_OF_YEAR, 6);

        String endDate = format.format(end.getTime());

        Statistics stats =
                eventManager.getWeeklyStatistics(startDate, endDate);

        String message =
                "Total Events: " + stats.getTotalEvents()
                        + "\n\nWork: " + stats.getWorkEvents()
                        + "\nSchool: " + stats.getSchoolEvents()
                        + "\nPersonal: " + stats.getPersonalEvents()
                        + "\nOther: " + stats.getOtherEvents();

        new AlertDialog.Builder(this)
                .setTitle("Weekly Statistics")
                .setMessage(message)
                .setPositiveButton("Close", null)
                .show();
    }

    private void loadEvents(String date) {
        loadEvents(date, "");
    }

    private void loadEvents(String date, String query) {
        events.clear();
        displayEvents.clear();

        events.addAll(eventManager.searchEvents(date, query));

        int selectedPosition = categorySpinner.getSelectedItemPosition();

        if (selectedPosition > 0) {
            Category selectedCategory = categories.get(selectedPosition - 1);
            events = EventFilter.filterByCategory(
                    events,
                    selectedCategory.getId());
        }

        if (!events.isEmpty()) {
            for (Event event : events) {
                displayEvents.add(event.getTitle() + " @ " + event.getTime());
            }
        } else {
            displayEvents.add("No events for this date");
        }

        adapter.notifyDataSetChanged();
    }

}
