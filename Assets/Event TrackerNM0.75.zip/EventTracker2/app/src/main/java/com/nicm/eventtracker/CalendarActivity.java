package com.nicm.eventtracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class CalendarActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private Button buttonAddEvent;
    private TextView eventsView;
    private ListView eventList;
    private EventDatabaseHelper dbHelper;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> eventData;
    private ArrayList<Integer> eventIds;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        calendarView = findViewById(R.id.calendarView);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        eventsView = findViewById(R.id.eventsView);
        eventList = findViewById(R.id.eventList);

        dbHelper = new EventDatabaseHelper(this);
        eventData = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventData);
        eventList.setAdapter(adapter);

        // Default day - today
        selectedDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
                .format(new java.util.Date(calendarView.getDate()));
        loadEvents(selectedDate);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            month += 1;
            selectedDate = String.format("%04d-%02d-%02d", year, month, dayOfMonth);
            eventsView.setText("Events for " + selectedDate + ":");
            loadEvents(selectedDate);
        });

        buttonAddEvent.setOnClickListener(v -> {
            Intent intent = new Intent(CalendarActivity.this, EventEditorActivity.class);
            intent.putExtra("date", selectedDate);
            startActivity(intent);
        });

        eventList.setOnItemClickListener((parent, view, position, id) -> {
            if (eventIds.size() <= position) {
                return;
            }

            int eventId = eventIds.get(position);
            String eventTitle = eventData.get(position);

            Intent intent = new Intent(CalendarActivity.this, EventEditorActivity.class);
            intent.putExtra("event_id", eventId);
            intent.putExtra("date", selectedDate);
            intent.putExtra("title", eventTitle);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents(selectedDate);
    }

    private void loadEvents(String date) {
        eventData.clear();
        if (eventIds == null) eventIds = new ArrayList<>();
        eventIds.clear();

        Cursor cursor = dbHelper.getEvents(date);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String title = cursor.getString(cursor.getColumnIndexOrThrow("title"));
                String time = cursor.getString(cursor.getColumnIndexOrThrow("time"));

                eventIds.add(id);
                eventData.add(title + " @ " + time);
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            eventData.add("No events for this date");
        }
        adapter.notifyDataSetChanged();
    }

}
